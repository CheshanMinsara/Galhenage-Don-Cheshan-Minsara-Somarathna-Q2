﻿using System.ComponentModel.DataAnnotations;

namespace FinalProject.Models
{
    public class Course
    {
        [Key]
        [Display(Name = "Course Id")]
        public int CourseId { get; set; }

        [Required]
        [Display(Name = "Course Name")]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Lecturer Name")]
        public string LecturerName { get; set; }
    }
}
