﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FinalProject.Models
{
    public class Student
    {
        [Key]
        [Display(Name = "Student Id")]
        public int StudentId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        [ForeignKey("Courses")]
        [Display(Name = "Course Id")]
        public int CourseId { get; set; }
    }
}
